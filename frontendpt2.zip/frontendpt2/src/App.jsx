import React from 'react';
import { BrowserRouter as Router, Route, Routes } from 'react-router-dom';
import Header from './components/Header.jsx';  // Incluye la extensión
import Footer from './components/Footer.jsx';  // Incluye la extensión
import Inicio from './components/Inicio.jsx';  // Incluye la extensión
import Catalogo from './components/Catalogo.jsx';  // Incluye la extensión
import Contacto from './components/Contacto.jsx';  // Incluye la extensión
import './App.css';

function App() {
  return (
    <Router>
      <Header />
      <Routes>
        <Route path="/" element={<Inicio />} />
        <Route path="/catalogo" element={<Catalogo />} />
        <Route path="/contacto" element={<Contacto />} />
      </Routes>
      <Footer />
    </Router>
  );
}

export default App;
