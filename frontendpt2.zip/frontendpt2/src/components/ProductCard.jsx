import React from 'react';
import './productCard.css';

function ProductCard({ producto, onEdit, onDelete, showActions }) {
  return (
    <div className="product-card">
      <img src={producto.imagen_url} alt={producto.nombre} className="product-image" />
      <div className="product-details">
        <h2>{producto.nombre}</h2>
        <p>{producto.descripcion}</p>
        <p className="price">Precio: ${parseFloat(producto.precio).toFixed(2)}</p>
        <p className="rating">Rating: {producto.rating}/10</p>
      </div>
      {showActions && (
        <div className="actions">
          <button className="edit-button" onClick={onEdit}>Editar</button>
          <button className="delete-button" onClick={onDelete}>Eliminar</button>
        </div>
      )}
    </div>
  );
}

export default ProductCard;
