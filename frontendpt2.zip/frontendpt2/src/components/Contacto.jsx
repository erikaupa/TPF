import React from 'react';
import './contacto.css';

function Contacto() {
  return (
    <div className="contacto">
      <h1>Contacto</h1>
      <p>Para cualquier consulta, por favor contáctanos a través de nuestro email: soporte@videogamecatalog.com</p>
    </div>
  );
}

export default Contacto;
