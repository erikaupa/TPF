import React from 'react';
import './contacto.css';

function Contacto() {
  return (
    <div className="contacto">
      <h2>Contacto</h2>
      <p>Para más información, por favor contacta con nosotros a través de nuestro correo: info@videogamecatalog.com</p>
    </div>
  );
}

export default Contacto;
