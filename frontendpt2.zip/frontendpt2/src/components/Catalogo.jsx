import React, { useState, useEffect } from 'react';
import axios from 'axios';
import './catalogo.css';
import ProductCard from './ProductCard';

function Catalogo() {
  const [productos, setProductos] = useState([]);
  const [categorias, setCategorias] = useState([]);
  const [filtroNombre, setFiltroNombre] = useState('');
  const [filtroCategoria, setFiltroCategoria] = useState('');
  const [filtroOrden, setFiltroOrden] = useState('');
  const [nuevoProducto, setNuevoProducto] = useState({
    nombre: '',
    descripcion: '',
    categoria_id: '',
    precio: '',
    rating: '',
    fecha_lanzamiento: '',
    proveedor_id: '',
    imagen_url: ''
  });
  const [editarProductoId, setEditarProductoId] = useState(null);

  useEffect(() => {
    axios.get('http://localhost:3000/api/productos')
      .then(response => {
        setProductos(response.data);
      })
      .catch(error => {
        console.error('Error al obtener los productos:', error);
      });

    axios.get('http://localhost:3000/api/categorias')
      .then(response => {
        setCategorias(response.data);
      })
      .catch(error => {
        console.error('Error al obtener las categorías:', error);
      });
  }, []);

  const handleChange = (e) => {
    setNuevoProducto({
      ...nuevoProducto,
      [e.target.name]: e.target.value
    });
  };

  const handleImageChange = (e) => {
    setNuevoProducto({
      ...nuevoProducto,
      imagen_url: URL.createObjectURL(e.target.files[0])
    });
  };

  const handleAddProducto = () => {
    if (editarProductoId) {
      axios.put(`http://localhost:3000/api/productos/${editarProductoId}`, nuevoProducto)
        .then(() => {
          setProductos(productos.map(prod => prod.id === editarProductoId ? nuevoProducto : prod));
          setEditarProductoId(null);
          setNuevoProducto({
            nombre: '',
            descripcion: '',
            categoria_id: '',
            precio: '',
            rating: '',
            fecha_lanzamiento: '',
            proveedor_id: '',
            imagen_url: ''
          });
        })
        .catch(error => {
          console.error('Error al actualizar el producto:', error);
        });
    } else {
      axios.post('http://localhost:3000/api/productos', nuevoProducto)
        .then(response => {
          setProductos([...productos, response.data]);
          setNuevoProducto({
            nombre: '',
            descripcion: '',
            categoria_id: '',
            precio: '',
            rating: '',
            fecha_lanzamiento: '',
            proveedor_id: '',
            imagen_url: ''
          });
        })
        .catch(error => {
          console.error('Error al agregar el producto:', error);
        });
    }
  };

  const handleEditProducto = (producto) => {
    setNuevoProducto(producto);
    setEditarProductoId(producto.id);
  };

  const handleDeleteProducto = (id) => {
    axios.delete(`http://localhost:3000/api/productos/${id}`)
      .then(() => {
        setProductos(productos.filter(prod => prod.id !== id));
      })
      .catch(error => {
        console.error('Error al eliminar el producto:', error);
      });
  };

  const productosFiltrados = productos
    .filter(producto => 
      producto.nombre.toLowerCase().includes(filtroNombre.toLowerCase()) &&
      (filtroCategoria === '' || producto.categoria_id === parseInt(filtroCategoria))
    )
    .sort((a, b) => {
      if (filtroOrden === 'precioAsc') return a.precio - b.precio;
      if (filtroOrden === 'precioDesc') return b.precio - a.precio;
      if (filtroOrden === 'ratingDesc') return b.rating - a.rating;
      return 0;
    });

  return (
    <div className="catalogo">
      <div className="filtro">
        <h2>Filtrar por</h2>
        <input 
          type="text" 
          className="input-filter" 
          placeholder="Buscar por nombre" 
          value={filtroNombre} 
          onChange={(e) => setFiltroNombre(e.target.value)} 
        />
        <select 
          className="input-filter" 
          value={filtroCategoria} 
          onChange={(e) => setFiltroCategoria(e.target.value)}
        >
          <option value="">Todas las categorías</option>
          {categorias.map(categoria => (
            <option key={categoria.id} value={categoria.id}>{categoria.nombre}</option>
          ))}
        </select>
        <select 
          className="input-filter" 
          value={filtroOrden} 
          onChange={(e) => setFiltroOrden(e.target.value)}
        >
          <option value="">Ordenar por</option>
          <option value="precioAsc">Precio: Menor a Mayor</option>
          <option value="precioDesc">Precio: Mayor a Menor</option>
          <option value="ratingDesc">Rating: Mayor a Menor</option>
        </select>
      </div>

      <div className="product-list">
        {productosFiltrados.map(producto => (
          <ProductCard
            key={producto.id}
            producto={producto}
            onEdit={() => handleEditProducto(producto)}
            onDelete={() => handleDeleteProducto(producto.id)}
            showActions={true}
          />
        ))}
      </div>

      <div className="add-product">
        <h2>{editarProductoId ? 'Editar Juego' : 'Agregar Nuevo Juego'}</h2>
        <input 
          type="text" 
          name="nombre" 
          placeholder="Nombre del Juego" 
          value={nuevoProducto.nombre} 
          onChange={handleChange} 
        />
        <textarea 
          name="descripcion" 
          placeholder="Descripción del Juego" 
          value={nuevoProducto.descripcion} 
          onChange={handleChange} 
        />
        <select 
          name="categoria_id" 
          value={nuevoProducto.categoria_id} 
          onChange={handleChange}
        >
          <option value="">Seleccionar Categoría</option>
          {categorias.map(categoria => (
            <option key={categoria.id} value={categoria.id}>{categoria.nombre}</option>
          ))}
        </select>
        <input 
          type="number" 
          name="precio" 
          placeholder="Precio del Juego" 
          value={nuevoProducto.precio} 
          onChange={handleChange} 
        />
        <input 
          type="number" 
          name="rating" 
          placeholder="Rating del Juego" 
          value={nuevoProducto.rating} 
          onChange={handleChange} 
        />
        <input 
          type="date" 
          name="fecha_lanzamiento" 
          placeholder="Fecha de Lanzamiento" 
          value={nuevoProducto.fecha_lanzamiento} 
          onChange={handleChange} 
        />
        <input 
          type="text" 
          name="proveedor_id" 
          placeholder="ID del Proveedor" 
          value={nuevoProducto.proveedor_id} 
          onChange={handleChange} 
        />
        <label htmlFor="file-upload" className="file-label">Subir Imagen</label>
        <input 
          id="file-upload" 
          type="file" 
          accept="image/jpeg" 
          onChange={handleImageChange} 
        />
        <button className="submit-button" onClick={handleAddProducto}>
          {editarProductoId ? 'Actualizar Juego' : 'Agregar Juego'}
        </button>
      </div>
    </div>
  );
}

export default Catalogo;
