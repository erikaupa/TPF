import React, { useState, useEffect } from 'react';
import axios from 'axios';
import './inicio.css';
import ProductCard from './ProductCard';

function Inicio() {
  const [productos, setProductos] = useState([]);

  useEffect(() => {
    axios.get('http://localhost:3000/api/productos')
      .then(response => {
        const productosOrdenados = response.data.sort((a, b) => b.rating - a.rating).slice(0, 6);
        setProductos(productosOrdenados);
      })
      .catch(error => {
        console.error('Error al obtener los productos:', error);
      });
  }, []);

  return (
    <div className="inicio">
      <h1>Mejores Juegos</h1>
      <div className="product-list">
        {productos.map(producto => (
          <ProductCard
            key={producto.id}
            producto={producto}
            showActions={false} // No mostrar botones en inicio
          />
        ))}
      </div>
    </div>
  );
}

export default Inicio;
