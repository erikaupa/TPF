document.getElementById('main-header').innerHTML = `
    <img src="assets/images/logo.png" alt="Logo de Video Games Catalog" class="logo">
    <nav>
        <ul>
            <li><a href="/">Inicio</a></li>
            <li><a href="/categorias">Categorías</a></li>
            <li><a href="/contacto">Contacto</a></li>
        </ul>
    </nav>
`;
