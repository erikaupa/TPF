document.getElementById('main-footer').innerHTML = `
    <p>&copy; 2024 Video Games Catalog. All rights reserved.</p>
`;
