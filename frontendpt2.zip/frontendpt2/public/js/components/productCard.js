function createProductCard(producto) {
    return `
        <div class="product-card">
            <img src="${producto.imagen_url}" alt="${producto.nombre}" class="product-image">
            <div class="product-details">
                <h2>${producto.nombre}</h2>
                <p>${producto.descripcion}</p>
                <p class="price">$${producto.precio}</p>
                <p class="rating">Rating: ${producto.rating}/10</p>
            </div>
        </div>
    `;
}
