document.addEventListener('DOMContentLoaded', () => {
  // Ejemplo de una acción básica al cargar la página
  console.log("Página cargada");
});
