const express = require('express');
const { obtenerProveedores } = require('../controllers/proveedorController');

const router = express.Router();

router.get('/', obtenerProveedores);

module.exports = router;
