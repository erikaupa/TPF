const express = require('express');
const { obtenerProductos, obtenerProducto, agregarProducto, editarProducto, eliminarProducto } = require('../controllers/productoController');

const router = express.Router();

router.get('/', obtenerProductos);
router.get('/:id', obtenerProducto);
router.post('/', agregarProducto);
router.put('/:id', editarProducto);
router.delete('/:id', eliminarProducto);

module.exports = router;
