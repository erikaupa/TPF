const { getAllProductos, getProductoById, createProducto, updateProducto, deleteProducto } = require('../models/productoModel');

const getAll = async (req, res, next) => {
    try {
        const productos = await getAllProductos();
        res.json(productos);
    } catch (error) {
        next(error);
    }
};

const getById = async (req, res, next) => {
    try {
        const producto = await getProductoById(req.params.id);
        if (producto) {
            res.json(producto);
        } else {
            res.status(404).json({ message: 'Producto no encontrado' });
        }
    } catch (error) {
        next(error);
    }
};

const create = async (req, res, next) => {
    try {
        const nuevoProducto = await createProducto(req.body);
        res.status(201).json(nuevoProducto);
    } catch (error) {
        next(error);
    }
};

const update = async (req, res, next) => {
    try {
        const productoActualizado = await updateProducto(req.params.id, req.body);
        if (productoActualizado) {
            res.json(productoActualizado);
        } else {
            res.status(404).json({ message: 'Producto no encontrado' });
        }
    } catch (error) {
        next(error);
    }
};

const remove = async (req, res, next) => {
    try {
        await deleteProducto(req.params.id);
        res.status(204).end();
    } catch (error) {
        next(error);
    }
};

module.exports = {
    getAll,
    getById,
    create,
    update,
    remove,
};
