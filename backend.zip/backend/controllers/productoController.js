const { getProductos, getProductoById, createProducto, updateProducto, deleteProducto } = require('../models/productoModel');

const obtenerProductos = async (req, res) => {
  try {
    const productos = await getProductos();
    res.json(productos);
  } catch (error) {
    res.status(500).json({ message: 'Error al obtener productos' });
  }
};

const obtenerProducto = async (req, res) => {
  try {
    const producto = await getProductoById(req.params.id);
    res.json(producto);
  } catch (error) {
    res.status(500).json({ message: 'Error al obtener el producto' });
  }
};

const agregarProducto = async (req, res) => {
  try {
    const nuevoProducto = await createProducto(req.body);
    res.status(201).json(nuevoProducto);
  } catch (error) {
    res.status(500).json({ message: 'Error al agregar el producto' });
  }
};

const editarProducto = async (req, res) => {
  try {
    const productoActualizado = await updateProducto(req.params.id, req.body);
    res.json(productoActualizado);
  } catch (error) {
    res.status(500).json({ message: 'Error al actualizar el producto' });
  }
};

const eliminarProducto = async (req, res) => {
  try {
    await deleteProducto(req.params.id);
    res.status(204).end();
  } catch (error) {
    res.status(500).json({ message: 'Error al eliminar el producto' });
  }
};

module.exports = {
  obtenerProductos,
  obtenerProducto,
  agregarProducto,
  editarProducto,
  eliminarProducto,
};
