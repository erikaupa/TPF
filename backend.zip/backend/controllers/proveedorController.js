const { getAllProveedores } = require('../models/proveedorModel');

const getAll = async (req, res, next) => {
  try {
    const proveedores = await getAllProveedores();
    res.json(proveedores);
  } catch (error) {
    next(error);
  }
};

module.exports = { getAll };
