const { getProveedores } = require('../models/proveedorModel');

const obtenerProveedores = async (req, res) => {
  try {
    const proveedores = await getProveedores();
    res.json(proveedores);
  } catch (error) {
    res.status(500).json({ message: 'Error al obtener proveedores' });
  }
};

module.exports = { obtenerProveedores };
