const { getCategorias } = require('../models/categoriaModel');

const obtenerCategorias = async (req, res) => {
  try {
    const categorias = await getCategorias();
    res.json(categorias);
  } catch (error) {
    res.status(500).json({ message: 'Error al obtener categorías' });
  }
};

module.exports = { obtenerCategorias };
