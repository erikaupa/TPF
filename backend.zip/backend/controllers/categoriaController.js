const { getAllCategorias } = require('../models/categoriaModel');

const getAll = async (req, res, next) => {
  try {
    const categorias = await getAllCategorias();
    res.json(categorias);
  } catch (error) {
    next(error);
  }
};

module.exports = { getAll };
