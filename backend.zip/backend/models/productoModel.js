const { pool } = require('../database/dbConfig');

const getAllProductos = async () => {
    const result = await pool.query('SELECT * FROM producto');
    return result.rows;
};

const getProductoById = async (id) => {
    const result = await pool.query('SELECT * FROM producto WHERE id = $1', [id]);
    return result.rows[0];
};

const createProducto = async (producto) => {
    const { nombre, descripcion, categoria_id, precio, rating, fecha_lanzamiento, proveedor_id, imagen_url } = producto;
    const result = await pool.query(
        'INSERT INTO producto (nombre, descripcion, categoria_id, precio, rating, fecha_lanzamiento, proveedor_id, imagen_url) VALUES ($1, $2, $3, $4, $5, $6, $7, $8) RETURNING *',
        [nombre, descripcion, categoria_id, precio, rating, fecha_lanzamiento, proveedor_id, imagen_url]
    );
    return result.rows[0];
};

const updateProducto = async (id, producto) => {
    const { nombre, descripcion, categoria_id, precio, rating, fecha_lanzamiento, proveedor_id, imagen_url } = producto;
    const result = await pool.query(
        'UPDATE producto SET nombre = $1, descripcion = $2, categoria_id = $3, precio = $4, rating = $5, fecha_lanzamiento = $6, proveedor_id = $7, imagen_url = $8 WHERE id = $9 RETURNING *',
        [nombre, descripcion, categoria_id, precio, rating, fecha_lanzamiento, proveedor_id, imagen_url, id]
    );
    return result.rows[0];
};

const deleteProducto = async (id) => {
    await pool.query('DELETE FROM producto WHERE id = $1', [id]);
};

module.exports = {
    getAllProductos,
    getProductoById,
    createProducto,
    updateProducto,
    deleteProducto,
};
