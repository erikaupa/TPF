const { pool } = require('../database/dbConfig');

const getAllCategorias = async () => {
  const result = await pool.query('SELECT * FROM categoria');
  return result.rows;
};

module.exports = { getAllCategorias };
