const { pool } = require('../database/dbConfig');

const getProveedores = async () => {
  const result = await pool.query('SELECT * FROM proveedor');
  return result.rows;
};

module.exports = { getProveedores };
